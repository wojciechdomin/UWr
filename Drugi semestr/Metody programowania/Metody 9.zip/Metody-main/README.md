# Metody
