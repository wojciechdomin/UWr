struct P {
    int len;
    float arr[];
};

float puzzle7(struct P *p, float f)
{
    int len = p->len;
    float *arr = p->arr;

    float res = 0.;
    float mult = 1.;

    for (int i = 0; i < len; i++)
    {
        res += arr[i] * mult;
        mult *= f;
    }

    return res;
}

/*
%rdi - p
%xmm0 - f
%rdx - len
%rcx - arr
%eax - count
%xmm1 - res
%xmm2 - mult

Program liczy sumę ważoną tablicy floatów
*/