#include <stdio.h>

struct node {
    char id[2];
    int (*hashfn)(char *);
    short flags;
    union {
        struct {
            short n_key;
            int n_data[2];
            unsigned char n_type;
        } s;
        unsigned l_value[2];
    } u;
};

/*
ABI 3.1.2

Structures and unions assume the alignment of their most strictly aligned component

char id[2]:
    alignment: 1
    offset: 0
    size: 2

PADDING 6

int (*hashfn)(char *):
    alignment: 8
    offset: 8
    size: 8

short flags:
    alignment: 2
    offset: 16
    size: 2

PADDING 6

union u:
    size: max(2, 2*4, 1) + 2*4 = 16
    alignment: max(8, 8) = 8
    offset: 24

Rozmiar struktury: 24+16 = 40B

*/



struct node_optimized {
    union {
        struct {
            short n_key;
            int n_data[2];
            unsigned char n_type;
        } s;
        unsigned l_value[2];
    } u;
    int (*hashfn)(char *);
    short flags;
    char id[2];
} x;

/*

Rozmiar node_optimized: 16 + 8 + 2 + 2 = 28

Bo nigdzie nie są potrzebne paddingi

*/