Dane:

```c
typedef struct {
    int x[A][B];
    long y;
} str1;

typedef struct {
    char array[B]; // 5+3, 6+2, 7+1 or 8+0 bytes
    int t; // 4 bytes
    short s[A]; // 2*A + pad
    long u; // 8 bytes
} str2;

void set_val(str1 *p, str2 *q) {
    long v1 = q->t;
    long v2 = q->u;
    p->y = v1 + v2;
}

```c


```s
set_val:
    movslq 8(%rsi), %rax
    addq 32(%rsi), %rax
    movq %rax, 184(%rdi)
    ret
```

%rdi - points to p
%rsi - points to q

%rax := *(q + 8B) + *(q + 32B)
*(p + 184) = %rax

1.
    B = 5 or 6 or 7 or 8

2.
    12 + 2*A + pad = 32
    2*A + pad = 20
    A = (20 - pad) / 2
    0 <= pad <= 7
    A = 7 or 8 or 9 or 10

3.
    4 * A * B + pad = 184
    A*B = 46 - pad/4
    0 <= pad <= 7
    pad = 0 or 4
    if pad = 0: nothing
    if pad = 4: A = 9, B = 5
