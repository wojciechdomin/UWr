```c
long A[R][S][T];
long store_elem(long i, long j, long k, long *dest)
{
    *dest = A[i][j][k];
    return sizeof(A);
}
```

```s
store_elem:
    leaq (%rsi,%rsi,2),%rax
    leaq (%rsi,%rax,4),%rax # %rax = 13*j
    movq %rdi,%rsi
    salq $6,%rsi
    addq %rsi,%rdi
    addq %rax,%rdi
    addq %rdi,%rdx
    movq A(,%rdx,8),%rax
    movq %rax,(%rcx)
    movq $3640,%rax
    ret
```


```
%rdi - i
%rsi - j
%rdx - k
%rcx - dest

rax = (3 * j) * 4 + j = 13 * j

i = 65*i + 13*j

k += i

dest = *(A + 5*13*i + 13*j + k)

S = 5
T = 13
sizeof(A) = 3640
R = 3640/8 / 5 / 13 = 7


```
