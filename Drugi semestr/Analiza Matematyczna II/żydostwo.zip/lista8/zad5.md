```c
union elem {
    struct {
        long *p;
        long y;
    } e1;

    struct {
        long x;
        union elem *next;
    } e2;
};
```

rozmiar e1:
    8 + 8 = 16

rozmiar e2:
    8 + 8 = 16

rozmiar elem: max(16, 16) = 16

```s
proc:
    movq 8(%rdi),%rax # pointer_to_next
    movq (%rax),%rdx # next_elem
    movq (%rdx),%rdx # value of p from next_elem
    subq 8(%rax),%rdx # p -= y
    movq %rdx,(%rdi)
```

proc w języku C:

```c
void proc(union elem *x)
{
    union elem *next_x = x->e2.next;
    long p_val = *next_x.e1.p;
    p_val -= next_x.e1.y;
    x->e2.x = p_val;
}
```
