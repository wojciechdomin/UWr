void merge1(long src1[], long src2[], long dest[], long n)
{
    long i1 = 0, i2 = 0;
    while (i1 < n && i2 < n)
        *dest++ = src1[i1] < src2[i2] ? src1[i1++] : src2[i2++];
}

// z flagą O5
void merge2(long src1[], long src2[], long dest[], long n)
{
    long i1 = 0, i2 = 0;
    while (i1 < n && i2 < n)
    {
        *dest = src1[i1];
        if(src1[i1] < src2[i2]) *dest = src2[i2];
        dest++;

        if(*dest == src1[i1]) i1++;

        if(*dest == src2[i2]) i2++;
    }
}

/*

W jakim celu procesor używa predyktora skoków?
W celu mniejszenia czasu trwania wykonywania. Pozwala wybrać brancha którego chcemy wykonywać jeszcze przed zewaluowaniem warunku

Które skoki warunkowe warto zoptymalizować do instrukcji cmov?
Wszystkie, które się da. W szczególności te, gdzie może wystąpić misprediction

Godbolt:

merge2(long*, long*, long*, long):
        testq   %rcx, %rcx
        jle     .L9
        pushq   %rbx
        xorl    %r8d, %r8d
        xorl    %eax, %eax
.L6:
        leaq    (%rdi,%rax,8), %r10
        leaq    (%rsi,%r8,8), %r11
        movq    (%r10), %rbx
        movq    %rbx, (%rdx)
        movq    (%r11), %r9
        cmpq    (%r10), %r9
        cmovle  %rbx, %r9
        addq    $8, %rdx
        movq    %r9, -8(%rdx)
        movq    (%rdx), %r9
        cmpq    (%r10), %r9
        sete    %r10b
        movzbl  %r10b, %r10d
        addq    %r10, %rax
        cmpq    (%r11), %r9
        sete    %r9b
        movzbl  %r9b, %r9d
        addq    %r9, %r8
        cmpq    %r8, %rax
        movq    %r8, %r9
        cmovge  %rax, %r9
        cmpq    %r9, %rcx
        jg      .L6
        popq    %rbx
        ret
.L9:
        ret

*/